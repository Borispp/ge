'use strict';

$(document).ready(function () {
  var $quantityDecrement = $('.js-quantity-decrement');
  var $quantityIncrement = $('.js-quantity-increment');

  $quantityDecrement.on('click', function () {
    var $quantityNumber = $(this).parent().find('.js-quantity-number');
    var quantityNumber = $quantityNumber.text();

    if (quantityNumber > 1) {
      $quantityNumber.html(+quantityNumber - 1);
    }
  });

  $quantityIncrement.on('click', function () {
    var $quantityNumber = $(this).parent().find('.js-quantity-number');
    var quantityNumber = $quantityNumber.text();

    $quantityNumber.html(+quantityNumber + 1);
  });

  // scrollToPage
  var $page = $('html,body');
  var scrollToPage = function scrollToPage(target) {
    var y = 0;
    if (target && $(target).length) {
      y = $(target).offset().top;
    }
    $page.animate({ scrollTop: y }, 300, 'swing');
    return;
  };

  $('.js-scrollto').on('click', function (e) {
    e.preventDefault();
    scrollToPage($(this).attr('href'));
    console.log('sss');
  });
});

var mapStyles = [{
  "elementType": "geometry",
  "stylers": [{
    "color": "#f5f5f5"
  }]
}, {
  "elementType": "labels.icon",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#616161"
  }]
}, {
  "elementType": "labels.text.stroke",
  "stylers": [{
    "color": "#f5f5f5"
  }]
}, {
  "featureType": "administrative.land_parcel",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#bdbdbd"
  }]
}, {
  "featureType": "poi",
  "elementType": "geometry",
  "stylers": [{
    "color": "#eeeeee"
  }]
}, {
  "featureType": "poi",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#757575"
  }]
}, {
  "featureType": "poi.park",
  "elementType": "geometry",
  "stylers": [{
    "color": "#e5e5e5"
  }]
}, {
  "featureType": "poi.park",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#9e9e9e"
  }]
}, {
  "featureType": "road",
  "elementType": "geometry",
  "stylers": [{
    "color": "#ffffff"
  }]
}, {
  "featureType": "road.arterial",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#757575"
  }]
}, {
  "featureType": "road.highway",
  "elementType": "geometry",
  "stylers": [{
    "color": "#dadada"
  }]
}, {
  "featureType": "road.highway",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#616161"
  }]
}, {
  "featureType": "road.local",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#9e9e9e"
  }]
}, {
  "featureType": "transit.line",
  "elementType": "geometry",
  "stylers": [{
    "color": "#e5e5e5"
  }]
}, {
  "featureType": "transit.station",
  "elementType": "geometry",
  "stylers": [{
    "color": "#eeeeee"
  }]
}, {
  "featureType": "water",
  "elementType": "geometry",
  "stylers": [{
    "color": "#c9c9c9"
  }]
}, {
  "featureType": "water",
  "elementType": "labels.text.fill",
  "stylers": [{
    "color": "#9e9e9e"
  }]
}];

// Google map
function initMap() {
  var place = { lat: 46.78, lng: 23.628760 };
  var placeMarker = { lat: 46.78, lng: 23.628760 };

  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 9,
    center: place,
    scrollwheel: false,
    styles: mapStyles
    // mapTypeId: google.maps.MapTypeId.HYBRID
  });

  var marker = new google.maps.Marker({
    position: placeMarker,
    animation: google.maps.Animation.DROP,
    icon: {
      url: './assets/images/content/marker.png',
      scaledSize: new google.maps.Size(26, 38)
    },
    map: map
    // 26, 38
  });
}